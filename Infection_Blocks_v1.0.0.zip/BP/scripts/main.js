import { world, system, BlockPermutation, BlockVolume } from "@minecraft/server";

/**
 * Infection Block Mod
 * - On first player spawn: place infection block under feet + 3s countdown (top-left style via title)
 * - After 3s: starts spreading
 * - Unbreakable, converts nearby blocks
 * - Entities stepping on it die instantly
 * - Deaths on it increase energy → faster spread
 */

const BLOCK_ID = "infection:infection_block";
const SPREAD_INTERVAL_TICKS = 20;      // base: try spread every 1 second
const MAX_SPREAD_PER_TICK = 8;         // safety limit
const ENERGY_PER_KILL = 0.35;          // each death on infection adds this to multiplier
const MAX_ENERGY = 8.0;

let started = false;
let energy = 1.0;                      // spread speed multiplier
let infected = new Set();              // "x,y,z,dim" keys of infected positions
let countdownDone = false;
let firstPlayer = null;

function posKey(dim, x, y, z) {
  return `${dim},${Math.floor(x)},${Math.floor(y)},${Math.floor(z)}`;
}

function parseKey(key) {
  const [dim, x, y, z] = key.split(",");
  return { dim, x: +x, y: +y, z: +z };
}

function placeInfection(dim, x, y, z) {
  try {
    const block = dim.getBlock({ x: Math.floor(x), y: Math.floor(y), z: Math.floor(z) });
    if (!block) return false;
    // do not overwrite already infected or bedrock/barrier
    if (block.typeId === BLOCK_ID) return true;
    if (block.typeId === "minecraft:bedrock" || block.typeId === "minecraft:barrier") return false;

    block.setPermutation(BlockPermutation.resolve(BLOCK_ID));
    infected.add(posKey(dim.id, x, y, z));
    return true;
  } catch (e) {
    return false;
  }
}

function isInfection(block) {
  return block && block.typeId === BLOCK_ID;
}

function showCountdown(player, secondsLeft) {
  try {
    // top-ish feel with title (center but large) + actionbar backup
    player.onScreenDisplay.setTitle(`§5§l${secondsLeft}`, {
      fadeInDuration: 0,
      stayDuration: 1.1,
      fadeOutDuration: 0.1,
      subtitle: "§d感染即将蔓延..."
    });
  } catch (_) {}
}

function startInfectionForPlayer(player) {
  if (started) return;
  started = true;
  firstPlayer = player;

  const loc = player.location;
  const dim = player.dimension;
  // place under feet
  const underY = Math.floor(loc.y) - 1;
  placeInfection(dim, loc.x, underY, loc.z);

  // also place at feet level if needed (in case floating)
  placeInfection(dim, loc.x, Math.floor(loc.y), loc.z);

  // 3 second countdown
  let left = 3;
  showCountdown(player, left);

  const countdownId = system.runInterval(() => {
    left--;
    if (left > 0) {
      showCountdown(player, left);
    } else {
      system.clearRun(countdownId);
      countdownDone = true;
      try {
        player.onScreenDisplay.setTitle("§c§l感染开始", {
          fadeInDuration: 0,
          stayDuration: 1.5,
          fadeOutDuration: 0.5,
          subtitle: "§4方块正在被侵蚀..."
        });
        dim.playSound("mob.wither.spawn", loc, { volume: 0.6, pitch: 0.7 });
      } catch (_) {}
    }
  }, 20);
}

// Listen for player spawn / join
world.afterEvents.playerSpawn.subscribe((ev) => {
  if (ev.initialSpawn && !started) {
    // small delay so location is ready
    system.runTimeout(() => {
      try {
        startInfectionForPlayer(ev.player);
      } catch (e) {
        console.warn("infection start: " + e);
      }
    }, 10);
  }
});

// Also cover case where player already in world when pack loads
system.runTimeout(() => {
  if (!started) {
    for (const p of world.getAllPlayers()) {
      startInfectionForPlayer(p);
      break;
    }
  }
}, 40);

// Spreading system
system.runInterval(() => {
  if (!countdownDone || infected.size === 0) return;

  const attempts = Math.min(MAX_SPREAD_PER_TICK, Math.ceil(2 * energy));
  const keys = Array.from(infected);
  // shuffle a bit for natural look
  for (let i = keys.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [keys[i], keys[j]] = [keys[j], keys[i]];
  }

  let converted = 0;
  const dirs = [
    [1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1],
    [1, 1, 0], [1, -1, 0], [-1, 1, 0], [-1, -1, 0],
    [0, 1, 1], [0, 1, -1], [0, -1, 1], [0, -1, -1]
  ];

  for (const key of keys) {
    if (converted >= attempts) break;
    const { dim: dimId, x, y, z } = parseKey(key);
    let dim;
    try {
      dim = world.getDimension(dimId);
    } catch { continue; }

    // random order of directions
    const shuffled = dirs.slice().sort(() => Math.random() - 0.5);
    for (const [dx, dy, dz] of shuffled) {
      if (converted >= attempts) break;
      const nx = x + dx, ny = y + dy, nz = z + dz;
      if (ny < -64 || ny > 320) continue;
      const nkey = posKey(dimId, nx, ny, nz);
      if (infected.has(nkey)) continue;

      try {
        const block = dim.getBlock({ x: nx, y: ny, z: nz });
        if (!block) continue;
        const tid = block.typeId;
        // skip air, liquids, already infected, unbreakable
        if (tid === "minecraft:air" || tid === "minecraft:cave_air" || tid === "minecraft:void_air") continue;
        if (tid === BLOCK_ID) {
          infected.add(nkey);
          continue;
        }
        if (tid === "minecraft:bedrock" || tid === "minecraft:barrier" || tid === "minecraft:command_block") continue;

        // convert
        if (placeInfection(dim, nx, ny, nz)) {
          converted++;
          // small particle for feedback
          try {
            dim.spawnParticle("minecraft:crop_growth_emitter", { x: nx + 0.5, y: ny + 0.5, z: nz + 0.5 });
          } catch {}
        }
      } catch {}
    }
  }
}, SPREAD_INTERVAL_TICKS);

// Instant death on infection blocks + energy boost
system.runInterval(() => {
  if (!countdownDone) return;

  for (const player of world.getAllPlayers()) {
    try {
      const loc = player.location;
      const block = player.dimension.getBlock({
        x: Math.floor(loc.x),
        y: Math.floor(loc.y - 0.2),
        z: Math.floor(loc.z)
      });
      if (isInfection(block)) {
        // kill and boost
        energy = Math.min(MAX_ENERGY, energy + ENERGY_PER_KILL);
        try {
          player.dimension.playSound("mob.wither.death", loc, { volume: 0.5, pitch: 1.4 });
        } catch {}
        player.kill();
        // feedback
        try {
          player.onScreenDisplay.setActionBar(`§c感染吞噬了你  §5能量 +${ENERGY_PER_KILL.toFixed(1)}  (当前 x${energy.toFixed(1)})`);
        } catch {}
      }
    } catch {}
  }

  // also kill nearby mobs (limited radius for performance)
  if (firstPlayer && firstPlayer.isValid) {
    try {
      const dim = firstPlayer.dimension;
      const entities = dim.getEntities({
        location: firstPlayer.location,
        maxDistance: 48,
        excludeTypes: ["minecraft:item", "minecraft:xp_orb", "minecraft:arrow"]
      });
      for (const e of entities) {
        if (e.typeId === "minecraft:player") continue;
        try {
          const loc = e.location;
          const block = dim.getBlock({
            x: Math.floor(loc.x),
            y: Math.floor(loc.y - 0.1),
            z: Math.floor(loc.z)
          });
          if (isInfection(block)) {
            energy = Math.min(MAX_ENERGY, energy + ENERGY_PER_KILL * 0.6);
            e.kill();
          }
        } catch {}
      }
    } catch {}
  }
}, 8); // check often for instant feel

// Prevent mining just in case (extra safety)
world.beforeEvents.playerBreakBlock.subscribe((ev) => {
  if (ev.block.typeId === BLOCK_ID) {
    ev.cancel = true;
    try {
      ev.player.onScreenDisplay.setActionBar("§c感染方块无法被破坏");
    } catch {}
  }
});

// Optional: show energy on occasional interval for the first player
system.runInterval(() => {
  if (!countdownDone || !firstPlayer || !firstPlayer.isValid) return;
  try {
    firstPlayer.onScreenDisplay.setActionBar(`§5感染能量 §f×${energy.toFixed(1)}  §8|  §7已感染方块 §f${infected.size}`);
  } catch {}
}, 40);
